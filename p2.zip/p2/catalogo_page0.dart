import 'package:flex_color_scheme/flex_color_scheme.dart';
import 'package:flutter/material.dart';

main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // Atualizações necessárias para funcionamento
      // flex_color_scheme
      theme: FlexThemeData.light(scheme: FlexScheme.amber),
      darkTheme: FlexThemeData.dark(scheme: FlexScheme.amber),
      themeMode: ThemeMode.dark,
      //themeMode: ThemeMode.light,
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black87,
        appBar: AppBar(
          backgroundColor: Colors.green,
          title: const Text(
            'Catálogo de Bandas',
            style: TextStyle(
                color: Colors.black87,
                fontSize: 30,
                fontFamily: 'Montserrat',
                fontWeight: FontWeight.w900),
          ),
          // Não esquecer de comentar ou remover a linha abaixo
          //backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          centerTitle: true,
        ),
        body: Row(
          children: [
            Container(
              margin: EdgeInsets.only(left: 40, top: 20, right: 40),
              width: 170,
              height: 100,
              child: Image.asset(
                'assets/images/uno.jpg',
                fit: BoxFit.cover,
              ),
            ),
            const Flexible(
              child: Text(
                'lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna',
                style: TextStyle(
                    fontFamily: 'Montserrat', fontWeight: FontWeight.normal),
                softWrap: true,
                maxLines: 4,
              ),
            ),
            Container(
              margin: const EdgeInsets.only(right: 40, left: 40, top: 20),
              child: ElevatedButton(
                onPressed: () => _showSnackBar(context),
                child: const Text('SnackBar'),
              ),
            ),
          ],
        ));
  }
}

void _showSnackBar(inContext) {
  ScaffoldMessenger.of(inContext).showSnackBar(
    SnackBar(
      backgroundColor: Colors.green,
      content: const Text(
        'Olá Pessoal',
        style: TextStyle(color: Colors.black87),
      ),
      action: SnackBarAction(
        label: 'Eu sou uma snackBar',
        textColor: Colors.brown,
        onPressed: () {},
      ),
    ),
  );
}
