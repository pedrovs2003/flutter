import 'package:flex_color_scheme/flex_color_scheme.dart';
import 'package:flutter/material.dart';

// *******************************************
//
// Layout Modelo Básico 2 - STATELESS
// Usando flex_color_scheme: ^7.0.0
// https://pub.dev/packages/flex_color_scheme
//
// ********************************************

// ATENÇÃO: Incluir no arquivo: pubspec.yaml
// em dependencies:
//   flex_color_scheme: ^7.0.0
//
// Não esquecer de rodar a aplicação novamente
// para que as atualizações do pubspec possam
// ser utilizadas na aplicação

main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // Atualizações necessárias para funcionamento
      // flex_color_scheme
      theme: FlexThemeData.light(scheme: FlexScheme.amber),
      darkTheme: FlexThemeData.dark(scheme: FlexScheme.amber),
      themeMode: ThemeMode.dark,
      //themeMode: ThemeMode.light,
      home: const Catalogo_page(),
    );
  }
}

class Catalogo_page extends StatelessWidget {
  const Catalogo_page({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black87,
        appBar: AppBar(
          leading: const BackButton(
            color: Colors.black87,
          ),
          backgroundColor: Colors.green,
          title: const Text(
            'Catálogo de Bandas',
            style: TextStyle(
              color: Colors.black87,
              fontSize: 30,
              fontFamily: 'Montserrat',
            ),
          ),
          // Não esquecer de comentar ou remover a linha abaixo
          //backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          centerTitle: true,
        ),
        body: ListView(
          children: [
            Column(
              children: [
                linhaDaMusica(context, 'assets/images/titan.jpg'),
                linhaDaMusica(context, 'assets/images/toro.webp'),
                linhaDaMusica(context, 'assets/images/twistter.jpg'),
                linhaDaMusica(context, 'assets/images/uno.jpg'),
                linhaDaMusica(context, 'assets/images/pcx.jpg'),
                linhaDaMusica(context, 'assets/images/titan.jpg'),
                linhaDaMusica(context, 'assets/images/toro.webp'),
                linhaDaMusica(context, 'assets/images/twistter.jpg'),
                linhaDaMusica(context, 'assets/images/uno.jpg'),
                linhaDaMusica(context, 'assets/images/pcx.jpg'),
                const SizedBox(
                  height: 20,
                )
              ],
            ),
          ],
        ));
  }

  SizedBox linhaDaMusica(BuildContext context, String foto) {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      height: 120,
      child: Row(
        children: [
          Container(
            margin: const EdgeInsets.only(left: 40, top: 20, right: 40),
            height: 100,
            width: 150,
            child: Image.asset(
              foto,
              fit: BoxFit.cover,
            ),
          ),
          const Flexible(
            child: Text(
              'lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna',
              softWrap: true,
              maxLines: 4,
            ),
          ),
          Container(
            margin: const EdgeInsets.only(right: 50, left: 50),
            child: ElevatedButton(
              onPressed: () => _showDialog(context),
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Colors.green),
                padding: MaterialStateProperty.all(const EdgeInsets.all(10)),
                textStyle:
                    MaterialStateProperty.all(const TextStyle(fontSize: 20)),
                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                  RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(40.0),
                  ),
                ),
              ),
              child: const SizedBox(
                width: 75,
                height: 35,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Ouvir',
                      style: TextStyle(
                          fontFamily: 'Montserrat Regular',
                          fontSize: 15,
                          fontWeight: FontWeight.bold),
                    ),
                    SizedBox(width: 5),
                    Icon(Icons.arrow_forward_ios_outlined),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

void _showDialog(inContext) {
  showDialog(
    context: inContext,
    // true: fecha o alerta se o usuário clicar em qualquer lugar na tela
    // false: não fecha o alerta se o usuário clicar em qualquer lugar na tela
    barrierDismissible: true,
    builder: (inContext) {
      return WillPopScope(
        // true: fecha o alerta se o usuário clicar em voltar
        // false: não fecha o alerta se o usuário clicar em voltar
        onWillPop: () async => false,
        child: AlertDialog(
          title: const Text(
            'Cadastre-se para ouvir as músicas',
            style: TextStyle(
                fontFamily: 'Montserrat Regular',
                fontWeight: FontWeight.bold,
                color: Colors.black87),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              TextButton(
                onPressed: () {
                  // Fecha a janela do alerta ao clicar em 'ok'
                  Navigator.pop(inContext);
                },
                child: const Text(
                  'OK',
                  style: TextStyle(
                      color: Colors.green, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          shape: RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(20.0), // Define as bordas arredondadas
          ),
          backgroundColor:
              Colors.green[100], // Define a cor de fundo como verde suave
        ),
      );
    },
  );
}
